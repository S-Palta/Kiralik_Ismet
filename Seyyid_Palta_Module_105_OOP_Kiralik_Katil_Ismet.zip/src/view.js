const submit = document.querySelector("#customerList");

submit.addEventListener("click",() => {
    let node = document.createElement("LI");
    let addressnode = document.addAddress();
});

// not completed to create a list on the DOM